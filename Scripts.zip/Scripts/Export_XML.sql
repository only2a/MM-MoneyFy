use MoneyFy;

go
create or alter procedure CategoryToXml
as
begin
	select Name, iconId, Type
	from Categories
		for xml path('category'), root('categories');
DECLARE @SQLCmd VARCHAR(8000)
	, @outputFileName VARCHAR(256) = 'D:\3SEM\DB\CW\categories.xml'
	, @SQL VARCHAR(2048) = 'use MoneyFy; select Name, iconId, Type from Categories for xml path(''category''), root(''categories'');';


SET @SQLCmd = FORMATMESSAGE('START "" "bcp" "%s" queryout "%s" -T -x -c -C 1252 -a 32768 -S %s'
				, @SQL
				, @outputFileName
				, @@SERVERNAME);



EXECUTE master.sys.xp_cmdshell @SQLCmd;
end; 

exec CategoryToXml

go
create or alter procedure IconsToXml
as
begin
	select Name, IconPath, Icons.Type
	from Icons
		for xml path('icon'), root('icons');

DECLARE @SQLCmd VARCHAR(8000)
	, @outputFileName VARCHAR(256) = 'D:\3SEM\DB\CW\icons.xml'
	, @SQL VARCHAR(2048) = 'use MoneyFy; select Name, IconPath, Type from Icons for xml path(''icon''), root(''icons'');';


SET @SQLCmd = FORMATMESSAGE('START "" "bcp" "%s" queryout "%s" -T -x -c -C 1252 -a 32768 -S %s'
				, @SQL
				, @outputFileName
				, @@SERVERNAME);



EXECUTE master.sys.xp_cmdshell @SQLCmd;
end; 



go
create or alter procedure CurrenciesToXml
as
begin
	select Name
	from Currencies
		for xml path('currency'), root('currencies');

DECLARE @SQLCmd VARCHAR(8000)
	, @outputFileName VARCHAR(256) = 'D:\3SEM\DB\CW\currencies.xml'
	, @SQL VARCHAR(2048) = 'use MoneyFy; select Name from Currencies for xml path(''currency''), root(''currencies'');';


SET @SQLCmd = FORMATMESSAGE('START "" "bcp" "%s" queryout "%s" -T -x -c -C 1252 -a 32768 -S %s'
				, @SQL
				, @outputFileName
				, @@SERVERNAME);



EXECUTE master.sys.xp_cmdshell @SQLCmd;
end; 






exec CategoryToXml;
exec IconsToXml;
exec CurrenciesToXml;