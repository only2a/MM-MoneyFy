CREATE NONCLUSTERED INDEX index_CurrencyName ON Currencies(Name);
alter table Currencies drop index index_CurrencyName;