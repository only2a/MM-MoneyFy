-- auto name generation
go 
Create Procedure CreateName
	@size integer,
	@Name char(50) OUTPUT
AS
Begin
	SET @Name = (
	SELECT
		c1 AS [text()]
	FROM
		(
		SELECT TOP (@size) c1
		FROM
		  (
		VALUES
		  ('A'), ('B'), ('C'), ('D'), ('E'), ('F'), ('G'), ('H'), ('I'), ('J'),
		  ('K'), ('L'), ('M'), ('N'), ('O'), ('P'), ('Q'), ('R'), ('S'), ('T'),
		  ('U'), ('V'), ('W'), ('X'), ('Y'), ('Z'),('a'), ('b'), ('c'), ('d'), 
		  ('e'), ('f'), ('g'), ('h'), ('i'),('j'),
		  ('k'), ('l'), ('m'), ('n'), ('o'), ('p'), ('q'), ('r'), ('s'), ('t'),
		  ('u'), ('v'), ('w'), ('x'), ('y'), ('z')
		  ) AS T1(c1)
		ORDER BY ABS(CHECKSUM(NEWID()))
		) AS T2
	FOR XML PATH('')
	);
End;
drop procedure CreateName;






go 
create or alter procedure EfficiencyTest
as
begin 
	declare @currencyName nvarchar(30),
			@number int;
	set @number = 1;
	while @number < 250000
		begin
			exec CreateName 3, @currencyName OUTPUT;
			insert into Currencies(Name)
			values(@currencyName);
			set @number = @number + 1;
		end;
end;
drop procedure EfficiencyTest;
exec EfficiencyTest;


select Name from Currencies ;


delete Currencies where id>15