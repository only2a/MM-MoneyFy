use master

create database MoneyFy;
use MoneyFy;
/*DROP DATABASE MoneyFy;*/

CREATE TABLE Users
(
Id int constraint PK_Users primary key (Id) identity(1,1),
IsAdmin bit NOT NULL default '0',
Name nvarchar(25) NOT NULL ,
Password nvarchar(max)  NOT NULL,
Login nvarchar(60) NOT NULL UNIQUE
)

CREATE TABLE Icons
(
Id int constraint PK_Icons primary key (Id) identity(1,1),
Name nvarchar(25) NOT NULL UNIQUE,
IconPath nvarchar(max)  NOT NULL,
Type nvarchar(25) not null
)

CREATE TABLE Currencies
(
Id int constraint PK_Currencies primary key (Id) identity(1,1),
Name nvarchar(60)  NOT NULL,
)

CREATE TABLE Categories
(
Id int constraint PK_Categories primary key (Id) identity(1,1),
iconId int constraint FK_Categories_Icons_iconId foreign key (iconId) references Icons(Id) ON DELETE CASCADE,
Name nvarchar(25) UNIQUE NOT NULL,
Type bit NOT NULL,
)



CREATE TABLE Accounts
(
Id int constraint PK_Accounts primary key (Id) identity(1,1),
Name nvarchar(25) NOT NULL ,
Balance decimal(18,2)  NOT NULL,
iconId int constraint FK_Accounts_Icons_iconId foreign key (iconId) references Icons(Id) ON DELETE CASCADE,
userId int constraint FK_Accounts_Users_userID foreign key (userId) references Users(Id) ON DELETE CASCADE,
CurrencyId int constraint FK_Accounts_Currencies_CurrencyId foreign key (CurrencyId) references Currencies(Id) ON DELETE CASCADE,
)

CREATE TABLE Operations
(
Id int constraint PK_Operations primary key (Id) identity(1,1),
CategoryId int constraint FK_Operations_Categories_CategoryId foreign key (CategoryId) references Categories(Id) ON DELETE CASCADE,
AccountId int constraint FK_Operations_Accounts_AccountId foreign key (AccountId) references Accounts(Id) ,
Name nvarchar(25) NOT NULL,
Date datetime2 Not null,
Sum decimal(18,2) not null
)


drop table Operations
drop table Accounts
drop table Categories
drop table Currencies
drop table Icons
drop table Users




