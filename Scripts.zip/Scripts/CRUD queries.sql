use MoneyFy;

--***************************************************
--		1.		USERS
--***************************************************

--CREATE

go
Create or alter Procedure CreateUser 
	@Name nvarchar(25), 
	@User_Login varchar(60),
	@User_Password varchar(max)
AS
Begin
	Insert into Users(Name,Login,Password)
	values(@Name, @User_Login, @User_Password);
End;



--DELETE 

go
create or alter Procedure DeleteUser
		@User_Id int
AS
Begin
	
	DECLARE @id int,@cat_id int,@acc_id int, @name nvarchar(25), @date datetime2, @sum decimal(18,2);
	DECLARE Operations_Delete_Cursor CURSOR LOCAL DYNAMIC
		for SELECT O.Id, O.CategoryId, O.AccountId, O.Name, O.Date, O.Sum  from Operations O join Accounts A on O.AccountId=A.Id where A.userId=@User_Id FOR UPDATE;
	OPEN Operations_Delete_Cursor
	fetch Operations_Delete_Cursor into @id ,@cat_id ,@acc_id , @name , @date , @sum;
			While (@@FETCH_STATUS = 0)
			  begin
				DELETE Operations where CURRENT OF Operations_Delete_Cursor;
				fetch Operations_Delete_Cursor into @id ,@cat_id ,@acc_id , @name , @date , @sum;
			  end;
	close Operations_Delete_Cursor;
	Delete Accounts where userId = @User_Id;
	Delete Users where Id=@User_Id;
End;

exec DeleteUser 5;

--UPDATE
go
Create or alter Procedure ChangeUserPassword
		@id int,
		@new_password nvarchar(max)
AS
Begin
	Update Users
	set Password = @new_password
	where Id = @id;
End;

go
Create or alter Procedure ChangeUserName
		@id int,
		@new_name nvarchar(60)
AS
Begin
	Update Users
	set Name = @new_name
	where Id = @id;
End;

exec ChangeUserName 5, Dima;
select * from Users;

--READ
go
Create or alter Procedure GetAllUsers
AS
Begin
	select * from Users;
End;

go
Create or alter Procedure GetUsers
AS
Begin
	select * from Users where IsAdmin = 0;
End;


go
Create or alter Procedure GetUserByLogin
				@email nvarchar(60)
AS
Begin
	select * from Users where Login = @email;
End;


go
Create or alter Procedure GetUserByLoginAndPassword
				@email nvarchar(60),
				@password nvarchar(max)
AS
Begin
	select * from Users where Login = @email And [Password] = @password;
End;

exec GetAllUsers;
--exec CreateUser 'User5','Login5','123';
--exec DeleteUser 6;
--exec ChangeUserPassword 'Login4', '1234';
--drop procedure GetAllUsers;
--drop procedure ChangeUserPassword;
--drop procedure DeleteUser;
--drop procedure CreateUser;

--***************************************************
--           2.    ACCOUNTS
--***************************************************

--CREATE 
go
Create or alter Procedure CreateAccount
		@Name nvarchar(25),
		@start_balance decimal(18,2),
		@icon_Id int,
		@user_Id int,
		@currency_Id int
AS
Begin
	Insert into Accounts(Name,Balance,iconId,userId, CurrencyId)
	values(@Name, @start_balance, @icon_Id,@user_Id,@currency_Id);
End;

exec CreateAccount Test, 1000, 1 , 5, 1
exec GetAllAccountsByUserId 5
delete Accounts where id = 13

exec DeleteAccount 14;
--DELETE
go
create or alter Procedure DeleteAccount
		@Account_Id int
AS
Begin
 begin tran;
	begin try
	  Delete Operations where AccountId = @Account_Id;
	  Delete Accounts where Id = @Account_Id;
	  commit;
	end try
	begin catch
	  rollback;
	end catch;
End;



--UPDATE
go
Create or alter Procedure UpdateAccount
		@Id int,
		@Name nvarchar(25),
		@Start_Balance decimal(18,2),
		@icon_Id int,
		@currency_Id int
AS
Begin
	Update Accounts
	set Name = @Name,
	Balance = @Start_Balance,
	iconId = @icon_Id,
	CurrencyId = @currency_Id
	where Id = @Id;
End;

go
Create or alter Procedure UpdateAccountBalance
		@Id int,
		@Sum decimal(18,2),
		@flag bit
AS
Begin
  if @flag=1 Update Accounts set Balance += @Sum where Id = @Id;
  else Update Accounts set Balance -= @Sum where Id = @Id;
End;

--READ
go
Create or alter Procedure GetAllAccounts
AS
Begin
	select * from Accounts;
End;


go
Create or alter Procedure GetAllAccountsByUserId @userId int
AS
Begin
	select * from Accounts where userId = @userId;
End;


go
Create or alter Procedure GetAccountById @Id int
AS
Begin
	select * from Accounts where Id = @Id;
End;


exec GetAllAccountsByUserId 5;
exec GetAccountById 2;
exec GetAllAccounts;
exec CreateAccount 'ABC',200,1,1,2;

--drop procedure GetAllAccounts;
--drop procedure CreateAccount;
--drop procedure UpdateAccount;
--drop procedure DeleteAccount;

--***************************************************
--        3.   OPERATIONS
--***************************************************

--CREATE
 
 go
Create or alter Procedure CreateOperation
		@categoryId int,
		@accountId int,
		@name nvarchar(25),
		@date datetime2,
		@sum decimal(18,2)
AS
Begin
	Insert into Operations(CategoryId,AccountId,Name,Date,Sum)
	values(@categoryId, @accountId,@name,@date,@sum);
End;


--DELETE

go
create or alter Procedure DeleteOperation
		@Operation_Id int
AS
Begin
	Delete Operations where Id = @Operation_Id;
End;

--UPDATE

go
Create or alter Procedure UpdateOperation
		@Id int,
		@categoryId int,
		@accountId int,
		@name nvarchar(25),
		@date datetime2,
		@sum decimal(18,2)
AS
Begin
	Update Operations
	set Name = @name,
	CategoryId = @categoryId,
	AccountId = @accountId,
	Date = @date,
	Sum = @sum
	where Id = @Id;
End;

--READ

go
Create or alter Procedure GetAllOperations
AS
Begin
	select * from Operations;
End;



go
Create or alter Procedure GetOperationById
			@Operation_Id int
AS
Begin
	select * from Operations where Id = @Operation_Id;
End;



go
Create or alter Procedure GetAllOperationsByAccountId
	@Account_Id int
AS
Begin
	select * from Operations where AccountId=@Account_Id
End;



go
Create or alter Procedure GetAllOperationsByUserId
	@User_Id int
AS
Begin
	select Operations.* from Operations join Accounts on Operations.AccountId = Accounts.Id
									   join Users on Accounts.userId=@User_Id;
End;


go
Create or alter Procedure GetAllOperationsByCategoryId
	@Category_Id int
AS
Begin
	select Operations.* from Operations where CategoryId=@Category_Id;
End;


go
Create or alter Procedure GetAllOperationsByName
	@Name nvarchar(25)
AS
Begin
	select * from Operations where Name like CONCAT('%',@Name,'%');
End;


go
Create or alter Procedure GetAllOperationsByAccountName
	@Name nvarchar(25)
AS
Begin
	select Operations.* from Operations join Accounts on Operations.AccountId = Accounts.Id
							where Accounts.Name like CONCAT('%',@Name,'%');
End;

exec GetAllOperationsByAccountName 'ank';
--drop procedure GetAllOperationsByAccountName

go
Create or alter Procedure GetAllOperationsByCategoryName
	@Name nvarchar(25)
AS
Begin
	select Operations.* from Operations join Categories on Operations.CategoryId = Categories.Id
							where Categories.Name like CONCAT('%',@Name,'%');
End;



go
Create or alter Procedure GetAllIncomeOperations 
		@userId int
AS
Begin
	select Operations.* from Operations join Accounts on Operations.AccountId = Accounts.Id
		join Users on Users.Id = Accounts.userId where sum>0 and Users.Id=@userId;
End;

exec GetAllIncomeOperations 5;

--exec GetAllIncomesOperations;

go
Create or alter Procedure GetAllWasteOperations
AS
Begin
	select * from Operations where sum<0;
End;


go
Create or alter Procedure GetAllIncomeOperationsByAccountId @Id int
AS
Begin
	select * from Operations where sum>0 AND AccountId = @Id;
End;


go
Create or alter Procedure GetAllWasteOperationsByAccountId @Id int
AS
Begin
	select * from Operations where sum<0 AND AccountId = @Id;;
End;

--***************************************************
--        4.   CATEGORIES
--***************************************************

--CREATE
 
 go
Create or alter Procedure CreateCategory
		@icon_Id int,
		@name nvarchar(25),
		@type bit
AS
Begin
	Insert into Categories(iconId,Name,Type)
	values(@icon_Id, @name,@type);
End;


--DELETE

go
create or alter Procedure DeleteCategory
		@Category_Id int
AS
Begin
	DECLARE @id int,@cat_id int,@acc_id int, @name nvarchar(25), @date datetime2, @sum decimal(18,2);
	DECLARE Operations_Delete_Cursor CURSOR LOCAL DYNAMIC
		for SELECT * from Operations  where CategoryId=@Category_Id FOR UPDATE;
	OPEN Operations_Delete_Cursor
	fetch Operations_Delete_Cursor into @id ,@cat_id ,@acc_id , @name , @date , @sum;
			While (@@FETCH_STATUS = 0)
			  begin
				DELETE Operations where CURRENT OF Operations_Delete_Cursor;
				fetch Operations_Delete_Cursor into @id ,@cat_id ,@acc_id , @name , @date , @sum;
			  end;
	close Operations_Delete_Cursor;
	Delete Categories where Id = @Category_Id;

End;

--UPDATE

go
Create or alter Procedure UpdateCategory
		@Id int,
		@icon_Id int,
		@name nvarchar(25),
		@type bit
AS
Begin
	Update Categories
	set iconId = @icon_Id,
	Name = @name,
	Type = @type
	where Id = @Id;
End;

--READ

go
Create or alter Procedure GetAllCategories
AS
Begin
	select * from Categories;
End;


go
Create or alter Procedure GetCategoryById @Id int
AS
Begin
	select * from Categories where Id=@Id;
End;


--***************************************************
--         5.  Icons
--***************************************************

--CREATE
 
 go
Create or alter Procedure CreateIcon
		@icon_path nvarchar(max),
		@name nvarchar(25),
		@type nvarchar(25)
AS
Begin
	Insert into Icons(IconPath,Name,Type)
	values(@icon_path, @name, @type);
End;


--DELETE

go
create or alter Procedure DeleteIcon
		@Id int
AS
Begin
	Delete Icons where Id = @Id;
End;

--UPDATE

go
Create or alter Procedure UpdateIcon
		@Id int,
		@icon_path nvarchar(max),
		@name nvarchar(25),
		@type nvarchar(25)
AS
Begin
	Update Icons
	set IconPath = @icon_path,
	Name = @name,
	Type = @type
	where Id = @Id;
End;

--READ

go
Create or alter Procedure GetAllIcons
AS
Begin
	select * from Icons;
End;

exec GetAllIcons
--***************************************************
--         6.  Currencies
--***************************************************

--CREATE
 
 go
Create or alter Procedure CreateCurrency
				@name nvarchar(60)
AS
Begin
	Insert into Currencies(Name)
	values(@name);
End;


--DELETE

go
create or alter Procedure DeleteCurrency
		@Id int
AS
Begin
	Delete Currencies where Id = @Id;
End;

--UPDATE

go
Create or alter Procedure UpdateCurrency
		@Id int,
		@name nvarchar(25)
AS
Begin
	Update Currencies
	set Name = @name
	where Id = @Id;
End;

--READ

go
Create or alter Procedure GetAllCurrencies
AS
Begin
	select * from Currencies;
End;