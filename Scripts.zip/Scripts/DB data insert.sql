use MoneyFy;

INSERT INTO  USERS VALUES('1','Admin','72JbMk1X/5msygjyn62JOA==','l0@mail.ru');
INSERT INTO  USERS VALUES('0','User1','72JbMk1X/5msygjyn62JOA==','l1@mail.ru');
INSERT INTO  USERS VALUES('0','User2','72JbMk1X/5msygjyn62JOA==','l2@mail.ru');
INSERT INTO  USERS VALUES('0','User3','72JbMk1X/5msygjyn62JOA==','l3@mail.ru');
INSERT INTO  USERS VALUES('0','User4','72JbMk1X/5msygjyn62JOA==','l4@mail.ru');



INSERT INTO  Icons VALUES('AlfaBank','D:\2SEM\OOP\kursach\MM-MoneyFy\Pictures\banks\alfa.png','account');
INSERT INTO  Icons VALUES('Sberbank','D:\2SEM\OOP\kursach\MM-MoneyFy\Pictures\banks\sber.png','account');
INSERT INTO  Icons VALUES('default','D:\2SEM\OOP\kursach\MM-MoneyFy\Pictures\banks\default.png','account');
INSERT INTO  Icons VALUES('paypal','D:\2SEM\OOP\kursach\MM-MoneyFy\Pictures\banks\paypal.png','account');
INSERT INTO  Icons VALUES('tinkoff','D:\2SEM\OOP\kursach\MM-MoneyFy\Pictures\banks\tinkoff.png','account');
INSERT INTO  Icons VALUES('webmoney','D:\2SEM\OOP\kursach\MM-MoneyFy\Pictures\banks\webmoney.png', 'account');
INSERT INTO  Icons VALUES('cash','D:\2SEM\OOP\kursach\MM-MoneyFy\Pictures\banks\cash.png', 'account');

INSERT INTO  Icons VALUES('medical','D:\2SEM\OOP\kursach\MM-MoneyFy\Pictures\Categories\medical.png','category');
INSERT INTO  Icons VALUES('credit','D:\2SEM\OOP\kursach\MM-MoneyFy\Pictures\Categories\credit.png', 'category');
INSERT INTO  Icons VALUES('salary','D:\2SEM\OOP\kursach\MM-MoneyFy\Pictures\Categories\salary.png', 'category');
INSERT INTO  Icons VALUES('scholarship','D:\2SEM\OOP\kursach\MM-MoneyFy\Pictures\Categories\scholarship.png', 'category');
INSERT INTO  Icons VALUES('car_washing','D:\2SEM\OOP\kursach\MM-MoneyFy\Pictures\Categories\car_washing.png', 'category');
INSERT INTO  Icons VALUES('part-time_job','D:\2SEM\OOP\kursach\MM-MoneyFy\Pictures\Categories\part-time_job.png', 'category');
INSERT INTO  Icons VALUES('celebration','D:\2SEM\OOP\kursach\MM-MoneyFy\Pictures\Categories\celebration.png', 'category');

INSERT INTO  Currencies VALUES('USD'); --1
INSERT INTO  Currencies VALUES('BYN'); --2
INSERT INTO  Currencies VALUES('EUR'); --3
INSERT INTO  Currencies VALUES('PLN'); --4
INSERT INTO  Currencies VALUES('RUB'); --5
INSERT INTO  Currencies VALUES('AUD'); --6
INSERT INTO  Currencies VALUES('GBP'); --7
INSERT INTO  Currencies VALUES('EGP'); --8
INSERT INTO  Currencies VALUES('INR'); --9
INSERT INTO  Currencies VALUES('KZT'); --10
INSERT INTO  Currencies VALUES('CNY'); --11
INSERT INTO  Currencies VALUES('KRW'); --12
INSERT INTO  Currencies VALUES('JPY'); --13
INSERT INTO  Currencies VALUES('SGD'); --14



select * from Icons;
select * from Users;
select * from Currencies;
select * from Accounts;

INSERT INTO  Accounts VALUES('Cash',200,7,2,2);
INSERT INTO  Accounts VALUES('Cash',200,7,3,2);
INSERT INTO  Accounts VALUES('Cash',200,7,4,2);
INSERT INTO  Accounts VALUES('Cash',200,7,5,2);
--User1
INSERT INTO  Accounts VALUES('Tinkoff',1230,5,2,1);
INSERT INTO  Accounts VALUES('PayPal',827,4,2,3);
--User2
INSERT INTO  Accounts VALUES('Sberbank',95637,2,3,5);
INSERT INTO  Accounts VALUES('WebMoney',15500,6,3,9);
--User3
INSERT INTO  Accounts VALUES('Tinkoff',80000,5,4,12);
INSERT INTO  Accounts VALUES('WebMoney',35500,6,4,13);
--User4
INSERT INTO  Accounts VALUES('Tinkoff',80000,5,5,7);
INSERT INTO  Accounts VALUES('AlfaBank',35500,1,5,2);


select * from Icons;
INSERT INTO  Categories VALUES( 10,'Salary',1);
INSERT INTO  Categories VALUES( 11,'Scholarship',1);
INSERT INTO  Categories VALUES( 13,'Part-time job',1);
INSERT INTO  Categories VALUES( 8,'Madical',0);
INSERT INTO  Categories VALUES( 9,'Credit',0);
INSERT INTO  Categories VALUES( 12,'Car washing',0);
INSERT INTO  Categories VALUES( 14,'Celebration',0);


select * from Categories;
select * from Operations;
select * from Accounts;
select * from Users;
INSERT INTO  Operations VALUES(2,12,'���������','2022-06-25 16:37:23',117);
INSERT INTO  Operations VALUES(2,12,'���������','2022-07-23 16:37:23',250);
INSERT INTO  Operations VALUES(2,12,'���������','2022-09-23 16:37:23',138);
INSERT INTO  Operations VALUES(2,12,'���������','2022-10-25 16:37:23',138);
INSERT INTO  Operations VALUES(1,11,'��������','2022-08-16 16:37:23',1500);
INSERT INTO  Operations VALUES(1,11,'��������','2022-09-16 16:37:23',1500);
INSERT INTO  Operations VALUES(1,11,'��������','2022-10-16 16:37:23',1500);
INSERT INTO  Operations VALUES(3,4,'����������','2022-09-10 16:37:23',21);
INSERT INTO  Operations VALUES(3,4,'����������','2022-09-13 16:37:23',14);
INSERT INTO  Operations VALUES(3,4,'����������','2022-10-21 16:37:23',42);

INSERT INTO  Operations VALUES(4,4,'����������','2022-10-10 16:37:23',-65);
INSERT INTO  Operations VALUES(4,4,'�����������','2022-10-20 16:37:23',-23);
INSERT INTO  Operations VALUES(5,12,'���������','2022-08-02 16:37:23',-142);
INSERT INTO  Operations VALUES(5,12,'���������','2022-09-02 16:37:23',-142);
INSERT INTO  Operations VALUES(5,12,'���������','2022-10-02 16:37:23',-142);
INSERT INTO  Operations VALUES(7,12,'�� ����','2022-10-11 16:37:23',-221);



select Operations.* from Operations join Accounts on Operations.AccountId = Accounts.Id
									join Users on Users.Id= Accounts.userId where Sum>0;

exec GetAllIncomeOperations 5;

select * from Operations;

delete Users;
delete Icons;
delete Operations;
delete Categories;
delete Accounts;
delete Currencies;

update Currencies set Name = 'Aaa' where id = 15
exec UpdateCurrency 15, 'Aaaa';

select * from Accounts where id = 1;
select * from Operations where AccountId = 1;

INSERT INTO  Operations VALUES(1,12,'���������','2022-06-25 16:37:23',11700);
INSERT INTO  Operations VALUES(5,1,'���������','2022-10-02 16:37:23',-117);

update Operations set Sum= -120 where id = 19;

delete Operations where id =18;

exec DeleteUser 5;

go
DECLARE @id int,@cat_id int,@acc_id int, @name nvarchar(25), @date datetime2, @sum decimal(18,2);
	DECLARE Operations_Delete_Cursor CURSOR LOCAL DYNAMIC
		for SELECT O.Id, O.CategoryId, O.AccountId, O.Name, O.Date, O.Sum  from Operations O join Accounts A on O.AccountId=A.Id where A.userId=5 FOR UPDATE;
	OPEN Operations_Delete_Cursor
		fetch Operations_Delete_Cursor into @id ,@cat_id ,@acc_id , @name , @date , @sum;
				DELETE Operations where CURRENT OF Operations_Delete_Cursor;
			While (@@FETCH_STATUS = 0)
				begin
				fetch Operations_Delete_Cursor into @id ,@cat_id ,@acc_id , @name , @date , @sum;
				DELETE Operations where CURRENT OF Operations_Delete_Cursor;
			end;
close Operations_Delete_Cursor;


select * from Accounts where Id=12;
select * from Operations;


exec DeleteCategory 1;