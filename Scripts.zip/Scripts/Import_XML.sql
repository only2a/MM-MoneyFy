
use MoneyFy;

go
create or alter procedure XmlToCategories
as begin
DECLARE @xml XML;

SELECT @xml = CONVERT(xml, BulkColumn, 2) FROM OPENROWSET(BULK 'D:\3SEM\DB\CW\categories.xml', SINGLE_BLOB) AS x

INSERT INTO  Categories(Name, iconId, Type)
SELECT 
	t.x.query('Name').value('.', 'nvarchar(25)'),
	t.x.query('iconId').value('.', 'int'),
	t.x.query('Type').value('.', 'bit')
FROM @xml.nodes('//categories/category') t(x)
end;

select * from Categories;
exec XmlToCategories;



go
create or alter procedure XmlToIcons
as begin
DECLARE @xml XML;

SELECT @xml = CONVERT(xml, BulkColumn, 2) FROM OPENROWSET(BULK 'D:\3SEM\DB\CW\icons.xml', SINGLE_BLOB) AS x

INSERT INTO  Icons(Name, IconPath, Type)
SELECT 
	t.x.query('Name').value('.', 'nvarchar(25)'),
	t.x.query('IconPath').value('.', 'nvarchar(max)'),
	t.x.query('Type').value('.', 'nvarchar(25)')
FROM @xml.nodes('//icons/icon') t(x)
end;

select * from Icons;
exec XmlToIcons;



go
create or alter procedure XmlToCaurrencies
as begin
DECLARE @xml XML;

SELECT @xml = CONVERT(xml, BulkColumn, 2) FROM OPENROWSET(BULK 'D:\3SEM\DB\CW\currencies.xml', SINGLE_BLOB) AS x

INSERT INTO  Currencies(Name)
SELECT 
	t.x.query('Name').value('.', 'nvarchar(25)')
FROM @xml.nodes('//currencies/currency') t(x)
end;

select * from Currencies;
exec XmlToCaurrencies;




