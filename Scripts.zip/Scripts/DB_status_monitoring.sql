
create table DiskActivityTest
(
	Id bigint constraint PK_Test primary key (Id) identity(1,1),
	str1 nvarchar(60) NOT NULL UNIQUE,
	str2 nvarchar(60) NOT NULL UNIQUE,
);

drop table DiskActivityTest

go 
create procedure DiskActivity
as
begin 
	declare @str1 nvarchar(60), @str2 nvarchar(60),
			@number int;
	set @number = 1;
	while @number < 100000
		begin
			exec CreateName 10, @str1 OUTPUT;
			exec CreateName 10, @str2 OUTPUT;
			insert into DiskActivityTest(str1,str2)
			values(@str1,@str2);
			set @number = @number + 1;
		end;
end;


exec DiskActivity

select CONCAT(str1,str2), SUBSTRING(str1,3,3) from DiskActivityTest

select avg(Id)*sum(Id),SUM(Id)*12,COUNT(*)*10 from DiskActivityTest where Id<50000