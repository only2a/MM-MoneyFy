USE master

CREATE LOGIN [User] WITH PASSWORD = 'User', DEFAULT_DATABASE = [MoneyFy];
CREATE LOGIN [Admin] WITH PASSWORD = 'Admin', DEFAULT_DATABASE = [MoneyFy];
CREATE LOGIN [Unauthuser] WITH PASSWORD = 'Unauthuser', DEFAULT_DATABASE = [MoneyFy];

drop login [User];
drop login [Admin];

USE [MoneyFy]    
CREATE USER [User] FOR LOGIN [User]   
    WITH DEFAULT_SCHEMA = dbo;  

CREATE USER [Admin] FOR LOGIN [Admin]   
    WITH DEFAULT_SCHEMA = dbo; 


CREATE USER [Unauthuser] FOR LOGIN [Unauthuser]   
    WITH DEFAULT_SCHEMA = dbo;
	
CREATE ROLE User_role AUTHORIZATION [User];
CREATE ROLE Admin_role AUTHORIZATION [Admin];

CREATE ROLE Unauthuser_role AUTHORIZATION [Unauthuser];


--User
GRANT SELECT ON DATABASE::[MoneyFy] TO  User_role;
GRANT INSERT ON DATABASE::[MoneyFy] TO  User_role;
GRANT UPDATE ON OBJECT::dbo.Accounts TO  User_role;
GRANT UPDATE ON OBJECT::dbo.Operations TO  User_role;
GRANT UPDATE ON OBJECT::dbo.Categories TO  User_role;
GRANT UPDATE ON OBJECT::dbo.Users TO  User_role;

GRANT EXECUTE ON OBJECT::[dbo].[CreateAccount] TO User_role;
GRANT EXECUTE ON OBJECT::dbo.CreateOperation TO User_role;
GRANT EXECUTE ON OBJECT::dbo.CreateCategory TO User_role;
GRANT EXECUTE ON OBJECT::dbo.DeleteAccount TO User_role;
GRANT EXECUTE ON OBJECT::dbo.DeleteOperation TO User_role;
GRANT EXECUTE ON OBJECT::dbo.DeleteCategory TO User_role;
GRANT EXECUTE ON OBJECT::dbo.GetAllAccounts TO User_role;
GRANT EXECUTE ON OBJECT::dbo.GetAllAccountsByUserId TO User_role;
GRANT EXECUTE ON OBJECT::dbo.GetAccountById TO User_role;
GRANT EXECUTE ON OBJECT::dbo.GetAllOperations TO User_role;
GRANT EXECUTE ON OBJECT::dbo.GetOperationById TO User_role;
GRANT EXECUTE ON OBJECT::dbo.GetAllOperationsByAccountId TO User_role;
GRANT EXECUTE ON OBJECT::dbo.GetAllOperationsByUserId TO User_role;
GRANT EXECUTE ON OBJECT::dbo.GetAllOperationsByCategoryId TO User_role;
GRANT EXECUTE ON OBJECT::dbo.GetAllOperationsByName TO User_role;
GRANT EXECUTE ON OBJECT::dbo.GetAllOperationsByAccountName TO User_role;
GRANT EXECUTE ON OBJECT::dbo.GetAllOperationsByCategoryName TO User_role;
GRANT EXECUTE ON OBJECT::dbo.GetAllIncomeOperations TO User_role;
GRANT EXECUTE ON OBJECT::dbo.GetAllWasteOperations TO User_role;
GRANT EXECUTE ON OBJECT::dbo.GetAllCategories TO User_role;
GRANT EXECUTE ON OBJECT::dbo.GetAllIcons TO User_role;
GRANT EXECUTE ON OBJECT::dbo.GetAllCurrencies TO User_role;
GRANT EXECUTE ON OBJECT::dbo.GetAllIncomeOperationsByAccountId TO User_role;
GRANT EXECUTE ON OBJECT::dbo.GetAllWasteOperationsByAccountId TO User_role;
GRANT EXECUTE ON OBJECT::dbo.UpdateCategory TO User_role;
GRANT EXECUTE ON OBJECT::dbo.UpdateOperation TO User_role;
GRANT EXECUTE ON OBJECT::dbo.UpdateAccount TO User_role;
GRANT EXECUTE ON OBJECT::dbo.ChangeUserPassword TO User_role;
GRANT EXECUTE ON OBJECT::dbo.ChangeUserName TO User_role;
GRANT EXECUTE ON OBJECT::dbo.GetAllCategories TO User_role;
GRANT EXECUTE ON OBJECT::dbo.GetCategoryById TO User_role;



--Admin
GRANT SELECT ON DATABASE::[MoneyFy] TO  Admin_role;
GRANT INSERT ON DATABASE::[MoneyFy] TO  Admin_role;
GRANT UPDATE ON OBJECT::Icons TO Admin_role;
GRANT UPDATE ON OBJECT::Currencies TO Admin_role;
GRANT UPDATE ON OBJECT::Categories TO Admin_role;


GRANT EXECUTE ON OBJECT::dbo.CreateCategory TO Admin_role;
GRANT EXECUTE ON OBJECT::dbo.CreateIcon TO Admin_role;
GRANT EXECUTE ON OBJECT::dbo.CreateCurrency TO Admin_role;
GRANT EXECUTE ON OBJECT::dbo.DeleteIcon TO Admin_role;
GRANT EXECUTE ON OBJECT::dbo.DeleteUser TO Admin_role;
GRANT EXECUTE ON OBJECT::dbo.DeleteCategory TO Admin_role;
GRANT EXECUTE ON OBJECT::dbo.DeleteCurrency TO Admin_role;
GRANT EXECUTE ON OBJECT::dbo.UpdateIcon TO Admin_role;
GRANT EXECUTE ON OBJECT::dbo.UpdateCategory TO Admin_role;
GRANT EXECUTE ON OBJECT::dbo.UpdateCurrency TO Admin_role;
GRANT EXECUTE ON OBJECT::dbo.GetUsers TO Admin_role;
GRANT EXECUTE ON OBJECT::dbo.GetAllCurrencies TO Admin_role;
GRANT EXECUTE ON OBJECT::dbo.GetAllIcons TO Admin_role;
GRANT EXECUTE ON OBJECT::dbo.GetAllCategories TO Admin_role;
GRANT EXECUTE ON OBJECT::dbo.GetUserByLogin TO Admin_role;

--Unauthuser
GRANT SELECT ON OBJECT::dbo.Users TO  Unauthuser_role;
GRANT INSERT ON OBJECT::dbo.Users TO  Unauthuser_role;

GRANT EXECUTE ON OBJECT::dbo.GetUserByLoginAndPassword TO Unauthuser_role;
GRANT EXECUTE ON OBJECT::dbo.CreateUser TO Unauthuser_role;
GRANT EXECUTE ON OBJECT::dbo.GetUserByLogin TO Unauthuser_role;
GRANT EXECUTE ON OBJECT::dbo.GetAllUsers TO Unauthuser_role;



select * from Operations;

