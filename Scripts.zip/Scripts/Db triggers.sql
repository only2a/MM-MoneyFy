use MoneyFy;


go
create or alter trigger NewOperations
on Operations
after insert  
as 
	begin
		DECLARE @newSum decimal(18,2);
		SELECT @newSum  = (SELECT Sum FROM inserted)
		DECLARE @id int
		SELECT @id  = (SELECT AccountId FROM inserted)
		 exec UpdateAccountBalance @id, @newSum, 1;	
end;



go
create or alter trigger DeleteOperations
on Operations
after delete  
as 
	begin
	DECLARE @newSum decimal(18,2);
		SELECT @newSum  = (SELECT Sum FROM deleted)
		DECLARE @id int
		SELECT @id  = (SELECT AccountId FROM deleted)
		 exec UpdateAccountBalance @id, @newSum, 0;
end;



go
create or alter trigger UpdateOperations
on Operations
after update  
as 
	begin
		DECLARE @oldSum decimal(18,2);
		SELECT @oldSum  = (SELECT Sum FROM deleted)
		DECLARE @newSum decimal(18,2);
		SELECT @newSum  = (SELECT Sum FROM inserted)
		DECLARE @id int
		SELECT @id  = (SELECT AccountId FROM deleted)
		 exec UpdateAccountBalance @id, @oldSum,0;
		 exec UpdateAccountBalance @id, @newSum,1;
end;



	







	--�������� ������ ���������
select * from Accounts where Id=12;
INSERT INTO  Operations VALUES(7,12,'TEST','2022-10-11 16:37:23',-20000);

select * from Operations;
delete Operations where Id=21;

update Operations set Sum = 20000 where Id=22;



exec UpdateAccountBalance 12,15000,1